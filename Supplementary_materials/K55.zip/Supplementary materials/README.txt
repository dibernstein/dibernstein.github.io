In a terminal window, first navigate to the folder that contains the geng file. Then run the following commands to generate the lists of all two-connected graphs with twenty-five edges and minimum degree 4 on 10, 11, and 12 vertices, and to save them to files:

./geng -C -d4 10 25:25 tenVertices.g6
./geng -C -d4 11 25:25 elevenVertices.g6
./geng -C -d4 12 25:25 twelveVertices.g6

In the Mathematica scripts, update the file paths to these three files and run them to verify the computations.